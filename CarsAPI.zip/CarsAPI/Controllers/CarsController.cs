﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarsAPI.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarsAPI.Controllers
{
    [Route("api")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        [HttpPost]
        public object Get(CarsDTO dto)
        {
            var names = dto.Cars.Select(car => car.Name);
            var sorted = dto.SortType 
                switch
            {
                "ASC" => names.OrderBy(o => o),
                "DSC" => names.OrderByDescending(o => o),
                _ => throw new NotImplementedException(),
            };
            var response = new
            {
                result = $"Hi {dto.Name}, your cars: {string.Join(' ', sorted)}" 
            };
            return response;
        }
    }
}
