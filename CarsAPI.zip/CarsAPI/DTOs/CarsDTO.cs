﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarsAPI.DTOs
{
    public class Car
    {
        public string Name { get; set; }

    }

    public class CarsDTO
    {
        public string Name { get; set; }
        public string SortType { get; set; }
        public List<Car> Cars { get; set; }

    }
}
